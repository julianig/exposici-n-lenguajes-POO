class RelojController < ApplicationController
  def mover_segundero
    @reloj = Reloj.new(params[:segundos].to_i, params[:minutos].to_i, params[:horas].to_i)
    @reloj.mover_segundero
    redirect_to root_path(segundos: @reloj.segundos, minutos: @reloj.minutos, horas: @reloj.horas)
  end

  def mover_minutero
    @reloj = Reloj.new(params[:segundos].to_i, params[:minutos].to_i, params[:horas].to_i)
    @reloj.mover_minutero
    redirect_to root_path(segundos: @reloj.segundos, minutos: @reloj.minutos, horas: @reloj.horas)
  end

  def mover_horario
    @reloj = Reloj.new(params[:segundos].to_i, params[:minutos].to_i, params[:horas].to_i)
    @reloj.mover_horario
    redirect_to root_path(segundos: @reloj.segundos, minutos: @reloj.minutos, horas: @reloj.horas)
  end

  def index
    @reloj = Reloj.new(params[:segundos].to_i, params[:minutos].to_i, params[:horas].to_i)
  end
end