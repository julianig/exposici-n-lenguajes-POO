class Reloj
  attr_accessor :segundos, :minutos, :horas

  def initialize(segundos = 0, minutos = 0, horas = 0)
    @segundos = segundos
    @minutos = minutos
    @horas = horas
  end

  def mover_segundero
    @segundos = (@segundos + 1) % 60
    mover_minutero if @segundos == 0
  end

  def mover_minutero
    @minutos = (@minutos + 1) % 60
    mover_horario if @minutos == 0
  end

  def mover_horario
    @horas = (@horas % 12) + 1
  end
end