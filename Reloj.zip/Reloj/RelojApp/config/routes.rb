Rails.application.routes.draw do
  root 'reloj#index'

  post 'mover_segundero', to: 'reloj#mover_segundero', as: :mover_segundero
  post 'mover_minutero', to: 'reloj#mover_minutero', as: :mover_minutero
  post 'mover_horario', to: 'reloj#mover_horario', as: :mover_horario
end
