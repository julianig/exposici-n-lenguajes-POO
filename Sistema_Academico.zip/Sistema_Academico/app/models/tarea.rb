# frozen_string_literal: true

class Tarea
  attr_accessor :nombre, :nota

  def initialize(nombre = "María José", nota = 4.5)
    @nombre = nombre
    @nota = nota
  end

  def ==(otro)
    return false unless otro.is_a?(Tarea)
    @nombre == otro.nombre
  end

  def to_s
    "Tarea{nombre='#{@nombre}', nota=#{@nota}}"
  end
end
