# frozen_string_literal: true

class Estudiante
  attr_accessor :codigo, :nombre, :tareas

  def initialize(codigo = 1152478, nombre = "María José")
    @codigo = codigo
    @nombre = nombre
    @tareas = []
  end

  def agregar_tarea(nombre, nota)
    nueva_tarea = Tarea.new(nombre, nota)
    unless @tareas.include?(nueva_tarea)
      @tareas << nueva_tarea
      return true
    end
    false
  end

  def eliminar_tarea(tarea)
    if @tareas.include?(tarea)
      @tareas.delete(tarea)
      return true
    end
    false
  end

  def ==(otro)
    return false unless otro.is_a?(Estudiante)
    @codigo == otro.codigo || @nombre == otro.nombre
  end

  def to_s
    "Estudiante{codigo=#{@codigo}, nombre='#{@nombre}', tareas=#{@tareas}}"
  end
end
