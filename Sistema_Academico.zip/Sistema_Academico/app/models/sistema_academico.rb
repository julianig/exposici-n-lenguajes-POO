# frozen_string_literal: true

class SistemaAcademico
  def initialize
    @estudiantes = []
  end

  def agregar_estudiante(codigo, nombre)
    nuevo_estudiante = Estudiante.new(codigo, nombre)
    unless @estudiantes.include?(nuevo_estudiante)
      @estudiantes << nuevo_estudiante
      return true
    end
    false
  end

  def eliminar_estudiante(estudiante)
    if @estudiantes.include?(estudiante)
      @estudiantes.delete(estudiante)
      return true
    end
    false
  end

  def estudiantes
    @estudiantes
  end
end
