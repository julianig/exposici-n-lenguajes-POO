require 'fox16' # Importamos la librería FXRuby
include Fox      # Incluimos el módulo Fox para usar sus clases y constantes

class Vista
  # @param [Object] controller
  def initialize(app, controller)
    @controller = controller

    # Crear la ventana principal
    @main_window = FXMainWindow.new(app, "Quiz ;)", width: 600, height: 400)

    # Contenedor principal
    main_layout = FXVerticalFrame.new(@main_window, LAYOUT_FILL)

    # Tabs
    tabs = FXTabBook.new(main_layout, nil, 0, LAYOUT_FILL)
    estudiantes_tab = FXTabItem.new(tabs, "Estudiantes")
    tareas_tab = FXTabItem.new(tabs, "Notas")

    # Panel de Estudiantes
    estudiantes_frame = FXVerticalFrame.new(tabs, LAYOUT_FILL)
    crear_panel_estudiantes(estudiantes_frame)

    # Panel de Tareas
    tareas_frame = FXVerticalFrame.new(tabs, LAYOUT_FILL)
    crear_panel_tareas(tareas_frame)
  end

  def crear_panel_estudiantes(parent)
    layout = FXVerticalFrame.new(parent, LAYOUT_FILL)

    # Formulario de Estudiantes
    form = FXHorizontalFrame.new(layout, LAYOUT_FILL_X)
    FXLabel.new(form, "Código:")
    @codigo_input = FXTextField.new(form, 10)

    FXLabel.new(form, "Nombre:")
    @nombre_input = FXTextField.new(form, 20)

    add_button = FXButton.new(form, "Agregar")
    delete_button = FXButton.new(form, "Eliminar")

    add_button.connect(SEL_COMMAND) do
      codigo = @codigo_input.text.to_i
      nombre = @nombre_input.text.strip
      @controller.agregar_estudiante(codigo, nombre)
    end

    delete_button.connect(SEL_COMMAND) do
      selected = @table_estudiantes.selStart
      if selected >= 0
        estudiante = @table_estudiantes.getItemText(selected, 1)
        @controller.eliminar_estudiante(estudiante)
      end
    end

    # Tabla de estudiantes
    @table_estudiantes = FXTable.new(layout, opts: LAYOUT_FILL | TABLE_COL_SIZABLE)
    @table_estudiantes.rowHeaderWidth = 0
    @table_estudiantes.columnHeaderVisible = true
    @table_estudiantes.setTableSize(0, 2)
    @table_estudiantes.setColumnText(0, "Código")
    @table_estudiantes.setColumnText(1, "Nombre")
  end

  def crear_panel_tareas(parent)
    layout = FXVerticalFrame.new(parent, LAYOUT_FILL)

    # Formulario de Tareas
    form = FXHorizontalFrame.new(layout, LAYOUT_FILL_X)
    FXLabel.new(form, "Estudiante:")
    @estudiantes_combo = FXComboBox.new(form, 10, opts: COMBOBOX_STATIC | FRAME_SUNKEN | FRAME_THICK)

    FXLabel.new(form, "Tarea:")
    @tarea_input = FXTextField.new(form, 20)

    FXLabel.new(form, "Nota:")
    @nota_input = FXTextField.new(form, 10)

    add_button = FXButton.new(form, "Agregar")
    delete_button = FXButton.new(form, "Eliminar")

    add_button.connect(SEL_COMMAND) do
      codigo_estudiante = @estudiantes_combo.currentItem
      nombre_tarea = @tarea_input.text.strip
      nota = @nota_input.text.to_f
      @controller.agregar_tarea(codigo_estudiante, nombre_tarea, nota)
    end

    delete_button.connect(SEL_COMMAND) do
      selected = @table_tareas.selStart
      if selected >= 0
        tarea = @table_tareas.getItemText(selected, 0)
        @controller.eliminar_tarea(tarea)
      end
    end

    # Tabla de tareas
    @table_tareas = FXTable.new(layout, opts: LAYOUT_FILL | TABLE_COL_SIZABLE)
    @table_tareas.rowHeaderWidth = 0
    @table_tareas.columnHeaderVisible = true
    @table_tareas.setTableSize(0, 2)
    @table_tareas.setColumnText(0, "Tarea")
    @table_tareas.setColumnText(1, "Nota")
  end

  # Métodos para actualizar datos
  def actualizar_estudiantes(estudiantes)
    @table_estudiantes.setTableSize(estudiantes.size, 2)
    estudiantes.each_with_index do |e, i|
      @table_estudiantes.setItemText(i, 0, e.codigo.to_s)
      @table_estudiantes.setItemText(i, 1, e.nombre)
    end
    @estudiantes_combo.clearItems
    estudiantes.each { |e| @estudiantes_combo.appendItem("#{e.codigo}-#{e.nombre}") }
  end

  def actualizar_tareas(tareas)
    @table_tareas.setTableSize(tareas.size, 2)
    tareas.each_with_index do |t, i|
      @table_tareas.setItemText(i, 0, t.nombre)
      @table_tareas.setItemText(i, 1, t.nota.to_s)
    end
  end

  def mostrar_error(mensaje)
    FXMessageBox.error(@main_window, MBOX_OK, "Error", mensaje)
  end

  def mostrar
    @main_window.show(PLACEMENT_SCREEN)
  end
end