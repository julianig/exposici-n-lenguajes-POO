# frozen_string_literal: true
require 'fox16'
require_relative 'views'

include Fox

app = FXApp.new
controller = nil
vista = Vista.new(app, controller)

app.create
vista.mostrar
app.run
