# frozen_string_literal: true

require_relative '../models/sistema_academico'
require_relative '../models/estudiante'
require_relative '../models/tarea'

class Controller
  attr_reader :sistema, :vista

  def initialize(vista)
    @sistema = SistemaAcademico.new
    @vista = vista
  end

  def agregar_estudiante(codigo, nombre)
    if @sistema.agregar_estudiante(codigo, nombre)
      @vista.actualizar_estudiantes(@sistema.estudiantes)
    else
      @vista.mostrar_error("El estudiante ya existe o los datos son inválidos.")
    end
  end

  def eliminar_estudiante(estudiante)
    if @sistema.eliminar_estudiante(estudiante)
      @vista.actualizar_estudiantes(@sistema.estudiantes)
      @vista.actualizar_tareas([])
    else
      @vista.mostrar_error("No se pudo eliminar el estudiante seleccionado.")
    end
  end

  def agregar_tarea(codigo_estudiante, nombre_tarea, nota)
    estudiante = @sistema.estudiantes.find { |e| e.codigo == codigo_estudiante }
    if estudiante
      if estudiante.agregar_tarea(nombre_tarea, nota)
        @vista.actualizar_tareas(estudiante.tareas)
      else
        @vista.mostrar_error("La tarea ya existe o los datos son inválidos.")
      end
    else
      @vista.mostrar_error("El estudiante no existe.")
    end
  end

  def eliminar_tarea(codigo_estudiante, tarea)
    estudiante = @sistema.estudiantes.find { |e| e.codigo == codigo_estudiante }
    if estudiante && estudiante.eliminar_tarea(tarea)
      @vista.actualizar_tareas(estudiante.tareas)
    else
      @vista.mostrar_error("No se pudo eliminar la tarea seleccionada.")
    end
  end

  def cargar_tareas(codigo_estudiante)
    estudiante = @sistema.estudiantes.find { |e| e.codigo == codigo_estudiante }
    if estudiante
      @vista.actualizar_tareas(estudiante.tareas)
    else
      @vista.actualizar_tareas([])
    end
  end
end
